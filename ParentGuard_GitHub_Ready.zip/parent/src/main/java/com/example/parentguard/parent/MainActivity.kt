package com.example.parentguard.parent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{ParentDashboard()}}
}
@Composable fun ParentDashboard(){
 var paired by remember{mutableStateOf(false)}
 MaterialTheme{Surface(Modifier.fillMaxSize()){Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 Text("ParentGuard",style=MaterialTheme.typography.headlineMedium)
 Text(if(paired)"Child device: CONNECTED" else "Child device: NOT PAIRED")
 Button(onClick={paired=true}){Text(if(paired)"Paired" else "Pair Child Device")}
 Text("Controls")
 OutlinedButton(onClick={}){Text("View Live Location")}
 OutlinedButton(onClick={}){Text("Screen Time & App Usage")}
 OutlinedButton(onClick={}){Text("Request Screen Share")}
 OutlinedButton(onClick={}){Text("Permission / Activity Log")}
 OutlinedButton(onClick={}){Text("Emergency / SOS")}
 Text("Production backend hooks are marked in the source. Add Firebase/WebRTC credentials before deployment.")
}}}}
