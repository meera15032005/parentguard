package com.example.parentguard.child
import android.Manifest
import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity:ComponentActivity(){
 private val perms=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){}
 private val screen=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ /* start approved foreground service here */ }
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{ChildScreen({requestPerms()},{requestScreen()})}}
 private fun requestPerms(){perms.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_MEDIA_IMAGES))}
 private fun requestScreen(){
   val m=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
   screen.launch(m.createScreenCaptureIntent())
 }
}
@Composable fun ChildScreen(permission:()->Unit, screen:()->Unit){
 var paired by remember{mutableStateOf(false)}
 MaterialTheme{Surface(Modifier.fillMaxSize()){Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 Text("ParentGuard Child",style=MaterialTheme.typography.headlineMedium)
 Text("This device is controlled transparently. Sensitive actions require Android consent.")
 Button(onClick={paired=true}){Text(if(paired)"Paired with Parent" else "Enter Parent Pairing Code")}
 Button(onClick=permission){Text("Grant / Review Permissions")}
 Button(onClick=screen){Text("Start Screen Sharing")}
 Text("Screen sharing shows Android's system consent dialog and must remain visible.")
}}}}
