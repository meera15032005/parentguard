# ParentGuard Full Starter
Two Android apps:
- `parent`: parent dashboard
- `child`: child-device companion

Included:
- Parent/child UI separation
- Pairing placeholder
- Location/camera/mic/photos runtime permission flow on child
- MediaProjection system-consent flow for screen sharing
- Dashboard controls and activity-log placeholders

Next production modules:
1. Firebase Auth + Firestore pairing
2. Secure device tokens and role-based access
3. Fused Location Provider + foreground location service
4. UsageStatsManager screen-time reports
5. Android Digital Wellbeing/accessibility-compatible app controls where permitted
6. WebRTC for consented live screen sharing
7. FCM commands/alerts
8. Audit log, revoke-pairing, encryption and data deletion
9. Proper foreground-service declarations and Android 14/15+ compliance

This starter deliberately does not implement hidden microphone/camera recording, covert screen capture, permission bypass, or spyware behavior.
