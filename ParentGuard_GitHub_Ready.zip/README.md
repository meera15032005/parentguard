# ParentGuard Full Starter

Two Android apps:
- `parent`: parent dashboard
- `child`: child-device companion

## Build fix included
This version uses Kotlin 2.0.21 with the matching Jetpack Compose compiler plugin (`org.jetbrains.kotlin.plugin.compose`), AndroidX configuration, and Java/Kotlin JVM target 17. The GitHub Actions workflow is self-contained and builds both debug APKs.

## GitHub Actions
1. Put this ZIP in the repository root with the exact filename `ParentGuard_GitHub_Ready.zip`.
2. Keep `.github/workflows/build.yml` from this project in the repository too, or copy its contents into the workflow file you already created.
3. Open **Actions → Build ParentGuard APK → Run workflow**.
4. When it succeeds, open the run and download the **ParentGuard-APKs** artifact.

## Included
- Parent/child UI separation
- Pairing placeholder
- Location/camera/mic/photos runtime permission flow on child
- MediaProjection system-consent flow for screen sharing
- Dashboard controls and activity-log placeholders

## Not included
No hidden microphone/camera recording, covert screen capture, permission bypass, or spyware behavior. Screen sharing uses Android's visible system consent flow.

## Production modules still needed
Firebase/Auth + secure pairing, real location service, UsageStats reports, permitted app controls, WebRTC for consented screen sharing, FCM commands, audit logs, encryption, data deletion, and production foreground-service declarations.
