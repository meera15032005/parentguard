package com.example.parentguard.child

import android.Manifest
import android.content.Context
import android.location.Location
import android.net.Uri
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch

private const val DATABASE_URL = "https://parentguard-bc22c-default-rtdb.asia-southeast1.firebasedatabase.app"

class MainActivity : ComponentActivity() {
    private var pairCode = ""
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    private val picker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty() && pairCode.isNotBlank()) uploadPhotos(uris)
    }
    private val camera = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null && pairCode.isNotBlank()) uploadCameraPhoto(bitmap)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChildApp() }
    }

    private fun auth(onReady: () -> Unit, onError: (String) -> Unit) {
        val a = FirebaseAuth.getInstance()
        if (a.currentUser != null) onReady() else a.signInAnonymously().addOnSuccessListener { onReady() }.addOnFailureListener { onError(it.message ?: "Auth failed") }
    }

    private fun join(code: String, result: (String) -> Unit) {
        auth({
            val ref = FirebaseDatabase.getInstance(DATABASE_URL).reference.child("pairs").child(code)
            ref.get().addOnSuccessListener { snap ->
                if (!snap.exists()) result("Invalid pairing code")
                else ref.child("childUid").setValue(FirebaseAuth.getInstance().currentUser!!.uid)
                    .addOnSuccessListener { pairCode = code; result("Connected to parent") }
                    .addOnFailureListener { result(it.message ?: "Pairing failed") }
            }.addOnFailureListener { result(it.message ?: "Could not check code") }
        }, result)
    }

    private fun shareLocation(result: (String) -> Unit) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            result("Allow location permission first")
            return
        }
        if (pairCode.isBlank()) { result("Pair the child phone first"); return }
        LocationServices.getFusedLocationProviderClient(this).getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { loc: Location? ->
                if (loc == null) result("Could not get location")
                else FirebaseDatabase.getInstance(DATABASE_URL).reference.child("pairs").child(pairCode).child("location")
                    .setValue(mapOf("lat" to loc.latitude, "lon" to loc.longitude, "time" to ServerValue.TIMESTAMP))
                    .addOnSuccessListener { result("Location shared") }
                    .addOnFailureListener { result(it.message ?: "Location upload failed") }
            }.addOnFailureListener { result(it.message ?: "Location error") }
    }

    private fun uploadPhotos(uris: List<Uri>) {
        auth({
            val db = FirebaseDatabase.getInstance(DATABASE_URL).reference.child("pairs").child(pairCode).child("photos")
            uris.forEach { uri ->
                val name = "photo_${System.currentTimeMillis()}_${uri.lastPathSegment?.takeLast(8) ?: "image"}"
                val ref = FirebaseStorage.getInstance().reference.child("photos/$pairCode/${FirebaseAuth.getInstance().currentUser!!.uid}/$name")
                ref.putFile(uri).continueWithTask { ref.downloadUrl }.addOnSuccessListener { url ->
                    val item = mapOf("url" to url.toString(), "name" to name, "time" to ServerValue.TIMESTAMP)
                    db.push().setValue(item)
                }
            }
        }, {})
    }


    private fun uploadCameraPhoto(bitmap: Bitmap) {
        auth({
            val uid = FirebaseAuth.getInstance().currentUser!!.uid
            val name = "camera_${System.currentTimeMillis()}.jpg"
            val ref = FirebaseStorage.getInstance().reference.child("photos/$pairCode/$uid/$name")
            val out = java.io.ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            ref.putBytes(out.toByteArray()).continueWithTask { ref.downloadUrl }
                .addOnSuccessListener { url ->
                    FirebaseDatabase.getInstance(DATABASE_URL).reference.child("pairs").child(pairCode).child("photos").push()
                        .setValue(mapOf("url" to url.toString(), "name" to name, "time" to ServerValue.TIMESTAMP, "source" to "camera"))
                }
        }, {})
    }

    @Composable
    private fun ChildApp() {
        var codeInput by remember { mutableStateOf("") }
        var connected by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Enter the pairing code from the parent phone") }
        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("ParentGuard Child", style = MaterialTheme.typography.headlineMedium)
                    Text("The child phone must explicitly share location and selected photos. Android permission dialogs are respected.")
                    OutlinedTextField(codeInput, { codeInput = it.uppercase().trim() }, label = { Text("Parent pairing code") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { join(codeInput) { msg -> connected = msg == "Connected to parent"; status = msg } }, enabled = codeInput.length >= 6) { Text("Connect to Parent") }
                    Text(status)
                    HorizontalDivider()
                    Button(onClick = { permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Text("Allow Location") }
                    Button(onClick = { shareLocation { status = it } }, enabled = connected) { Text("Share Current Location") }
                    Button(onClick = { picker.launch("image/*") }, enabled = connected) { Text("Select Photos to Share") }
                    Button(onClick = {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            camera.launch(null)
                        } else {
                            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                        }
                    }, enabled = connected) { Text("Take Photo and Share") }
                    Text("Camera use is visible and requires Android permission. Photos are shared only after an action on the child phone.")
                }
            }
        }
    }
}
