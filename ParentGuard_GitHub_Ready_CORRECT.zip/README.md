# ParentGuard

Transparent two-phone parental-control prototype for one parent and two child devices.

## Current safe features
- Firebase Anonymous Authentication
- Realtime Database pairing and current-location sharing
- Explicit child-side photo selection and visible camera action
- No hidden microphone/camera recording and no covert screen capture

## Firebase configuration
The Android apps use their matching `google-services.json` files and the Realtime Database URL for the Singapore database created for project `parentguard-bc22c`.

Before testing pairing/location, update Realtime Database Rules so authenticated users can access only the data they are authorized to use. Keep the database locked until those rules are configured.

## Build
GitHub Actions builds `:parent:assembleDebug` and `:child:assembleDebug` directly from this repository.

## Important
Camera, location, and photo sharing respect Android permission and user-action requirements. The app does not secretly record or capture the child device.
