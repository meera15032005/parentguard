package com.example.parentguard.parent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.launch
import kotlin.random.Random

private data class Photo(val url: String = "", val name: String = "", val time: Long = 0)

private const val DATABASE_URL = "https://parentguard-bc22c-default-rtdb.asia-southeast1.firebasedatabase.app"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ParentApp() }
    }
}

@Composable
private fun ParentApp() {
    var code by remember { mutableStateOf("") }
    var connected by remember { mutableStateOf(false) }
    var lat by remember { mutableStateOf<Double?>(null) }
    var lon by remember { mutableStateOf<Double?>(null) }
    var status by remember { mutableStateOf("Not connected") }
    var photos by remember { mutableStateOf<List<Photo>>(emptyList()) }
    val context = LocalContext.current

    fun ensureAuth(onReady: () -> Unit) {
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) onReady() else auth.signInAnonymously()
            .addOnSuccessListener { onReady() }
            .addOnFailureListener { status = "Firebase Auth failed: ${it.message}" }
    }

    fun listen(pairCode: String, update: (Boolean, Double?, Double?, List<Photo>) -> Unit) {
        val ref = FirebaseDatabase.getInstance(DATABASE_URL).reference.child("pairs").child(pairCode)
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val childUid = s.child("childUid").getValue(String::class.java)
                val la = s.child("location/lat").getValue(Double::class.java)
                val lo = s.child("location/lon").getValue(Double::class.java)
                val list = s.child("photos").children.mapNotNull { x ->
                    val u = x.child("url").getValue(String::class.java) ?: return@mapNotNull null
                    Photo(u, x.child("name").getValue(String::class.java) ?: "Photo", x.child("time").getValue(Long::class.java) ?: 0)
                }.sortedByDescending { it.time }
                update(childUid != null, la, lo, list)
            }
            override fun onCancelled(e: DatabaseError) { status = e.message }
        })
    }

    fun createPair() {
        ensureAuth {
            val newCode = buildString { repeat(8) { append("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Random.nextInt(32)]) } }
            val ref = FirebaseDatabase.getInstance(DATABASE_URL).reference.child("pairs").child(newCode)
            ref.setValue(mapOf("parentUid" to FirebaseAuth.getInstance().currentUser!!.uid, "createdAt" to ServerValue.TIMESTAMP))
                .addOnSuccessListener { code = newCode; status = "Give this code to the child phone"; listen(newCode, {c, la, lo, p -> connected=c; lat=la; lon=lo; photos=p}) }
                .addOnFailureListener { status = "Create failed: ${it.message}" }
        }
    }



    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Text("ParentGuard", style = MaterialTheme.typography.headlineMedium)
                    Text("Transparent parent-control dashboard")
                }
                item {
                    Button(onClick = { createPair() }, enabled = code.isEmpty()) { Text("Create Child Pairing Code") }
                    if (code.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Pairing code", style = MaterialTheme.typography.titleMedium)
                        Text(code, style = MaterialTheme.typography.headlineLarge)
                        Text(if (connected) "🟢 Child connected" else "🟡 Waiting for child…")
                        Text(status)
                    }
                }
                item {
                    HorizontalDivider()
                    Text("Location", style = MaterialTheme.typography.titleLarge)
                    if (lat != null && lon != null) {
                        Text("Latitude: $lat\nLongitude: $lon")
                        Button(onClick = {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon")))
                        }) { Text("Open Location in Maps") }
                    } else Text("No location shared yet")
                }
                item {
                    HorizontalDivider()
                    Text("Shared gallery photos", style = MaterialTheme.typography.titleLarge)
                    Text("Only photos explicitly shared from the child phone appear here.")
                }
                items(photos) { photo ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(8.dp)) {
                            AsyncImage(model = photo.url, contentDescription = photo.name, modifier = Modifier.fillMaxWidth().height(220.dp))
                            Text(photo.name)
                        }
                    }
                }
            }
        }
    }
}
